<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\LogPanggilan;
use Illuminate\Support\Facades\DB;

class logController extends Controller
{
    function index(){
        $data['list_log'] = LogPanggilan::all();
        return view('admin.log.index',$data);
    }
}
