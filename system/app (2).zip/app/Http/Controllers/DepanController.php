<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\edukasi;
use App\Models\Pertanyaan;
use App\Models\ruleDetail;
use App\Models\rule;
use App\Models\cekNilai;
use App\Models\Deskripsi;
use App\Models\penanganan;
use App\Models\LogPanggilan;

class DepanController extends Controller
{
    function index(){
        $data['list_edukasi'] = edukasi::all();
        return view('landing.index',$data);
    }
    function layanan(){
        $data['list_edukasi'] = edukasi::all();
        return view('landing.layanan',$data);
    }
    function penanganan($id){
         $deskripsi = $data['deskripsi'] = Deskripsi::find($id);
        
        return view('landing.penanganan',$data);
    }
    function dashboard(){
        $data['jumlahLog'] = LogPanggilan::count();
        $data['tertangani'] = LogPanggilan::where('penanganan','tertangani')->count();
        $data['tidak'] = LogPanggilan::where('penanganan','tidak tertangani')->count();
        $data['edukasi'] = edukasi::count();
        return view('admin.dashboard',$data);
    }
    function daftar($id){
        $edukasi = $data['edukasi'] = edukasi::find($id);
        if($edukasi->pertanyaan == 1){
            $data['list_pertanyaan'] = Pertanyaan::where('id_jenis_edukasi',$id)->get();
            return view('daftar',$data);
        }else{
            $data['list_deskripsi'] = Deskripsi::where('id_jenis_edukasi',$id)->get();
            return view('landing.edukasi',$data);
        }
    }
    function adddaftar(){
        $list_data = Pertanyaan::where('id_jenis_edukasi',request('id_jenis_edukasi'))->get();
        foreach($list_data as $data){
            $rule = new rule;
            $rule->id_edukasi = $data->id_jenis_edukasi;
            $rule->id_pertanyaan = request('id_'.$data->id);
            $rule->id_deskripsi = request('deskripsi_'.$data->id);
            $rule->status = request($data->id);
            $rule->status_transaksi = 0;
            $rule->save();
        }
        return redirect('cekPenyakit');
    }
    function cekPenyakit(){
        $kk = rule::where('status',1)->where('status_transaksi',0)->groupBy('id_deskripsi')->get();
   
        foreach($kk as $bb){
            $data = rule::where('id_deskripsi',$bb->id_deskripsi)->where('status',1)->where('status_transaksi',0)->count();
            $ceknilai = DB::table('ceknilai')->insert([
                'id_edukasi'=> $bb->id_edukasi,
                'id_deskripsi'=> $bb->id_deskripsi,
                'nilai' => $data,
                'status' => '0'
            ]);
        }
        return redirect('Penyakit');
     
    }
    function Penyakit(){
        $nilaimax = cekNilai::where('status',0)->max('nilai');
        $data['hasil'] = cekNilai::where('nilai',$nilaimax)->where('status',0)->first();
        return view('landing.hasil',$data);
    }

    function tertangani($id_edukasi,$id_deskripsi){
        rule::where('id_edukasi',$id_edukasi)->delete();
        cekNilai::where('id_edukasi',$id_edukasi)->delete();

        $log = new LogPanggilan;
        $log->id_deskripsi = $id_deskripsi;
        $log->penanganan = 'tertangani';
        $log->save();
        return redirect('layanan')->with('tertangani','kasus tertangani');
    }

    function takTertangani($id_edukasi,$id_deskripsi){
        rule::where('id_edukasi',$id_edukasi)->delete();
        cekNilai::where('id_edukasi',$id_edukasi)->delete();

        $log = new LogPanggilan;
        $log->id_deskripsi = $id_deskripsi;
        $log->penanganan = 'tidak tertangani';
        $log->save();
        return redirect('layanan')->with('taktertangani','kasus tidak tertangani');
    }

    //
}
