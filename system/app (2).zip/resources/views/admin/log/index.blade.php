@extends('template2.base')
@section('content') 
  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                           <div class="page_title">
                              <h2>Log Panggailan</h2>
                           </div>
                        </div>
                     </div>
                     <!-- row -->
                     <div class="row column4 graph">
                        <!-- Gallery section -->
                        <div class="col-md-12">
                           <div class="white_shd full margin_bottom_30">
                              <div class="full graph_head">
                                 <div class="heading1 margin_0">
                                    
                                  
                                 </div>
                              </div>
                              <div class="table_section padding_infor_info">
                                 <div class="table-responsive-sm">
                                    <table id="example" class="display" style="width:100%">
            <thead>
               <tr>
                  <th>NO</th>
                  <th>LOG PANGGILAN</th>
                  <th>TANGGAL</th>
                  <th>STATUS</th>
               </tr>
            </thead>
            <tbody>
               @foreach($list_log as $key=>$log)
               <tr>
                  <td>{{$key+1}}</td>
                  <td>{{$log->subEdukasi->nama_edukasi}}</td>
                  <td>{{date('D M Y', strtotime($log->created_at))}}</td>
                  <td>{{$log->penanganan}}</td>
               </tr>

               @endforeach
            </tbody>
            
         </table>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- footer -->

@endsection
@section('script')
<script> 
   new DataTable('#example');
</script>
@endsection 



