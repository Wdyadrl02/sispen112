 <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Sispen 112</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- site icon -->
      <link rel="icon" href="{{url('public')}}/logo112.png" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="{{url('public/assets3')}}/css/bootstrap.min.css" />
      <!-- site css -->
      <link rel="stylesheet" href="{{url('public/assets3')}}/style.css" />
      <!-- responsive css -->
      <link rel="stylesheet" href="{{url('public/assets3')}}/css/responsive.css" />
      <!-- color css -->
      <link rel="stylesheet" href="{{url('public/assets3')}}/css/color_2.css" />
      <!-- select bootstrap -->
      <link rel="stylesheet" href="{{url('public/assets3')}}/css/bootstrap-select.css" />
      <!-- scrollbar css -->
      <link rel="stylesheet" href="{{url('public/assets3')}}/css/perfect-scrollbar.css" />
      <!-- custom css -->
      <link rel="stylesheet" href="{{url('public/assets3')}}/css/custom.css" />\

     <link rel="stylesheet" href=" {{url('public')}}/assets/datatables.net-dt/css/jquery.dataTables.min.css">
     <style>
          .active2 {
         box-shadow: 2px 2px 5px #fc894d;
     }
     </style>